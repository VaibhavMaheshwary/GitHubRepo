package com.grammer.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Paragraph;
import com.grammer.Punctuation;
import com.grammer.Statement;
import com.grammer.Word;
import com.grammer.interfaces.StatementElement;

public class ParagraphTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetStatementList() {

		List<Statement> statementList = new ArrayList<Statement>();
		StatementElement stmtElement1 = new Word("Hello");
		StatementElement stmtElement2 = new Punctuation('?');
		
		List<StatementElement> stmtElementList = new ArrayList<StatementElement>();
		stmtElementList.add(stmtElement1);
		stmtElementList.add(stmtElement2);
		
		Statement stmt =new Statement();
		stmt.setStmtElementList(stmtElementList);
		statementList.add(stmt);
		
		Paragraph para = new Paragraph();
		para.setStatementList(statementList);
		
		assertEquals(1, para.getStatementList().size());
		
		
	}

	@Test
	public void testSetStatementList() {
		List<Statement> statementList = new ArrayList<Statement>();
		StatementElement stmtElement1 = new Word("Hello");
		StatementElement stmtElement2 = new Punctuation('?');
		
		List<StatementElement> stmtElementList = new ArrayList<StatementElement>();
		stmtElementList.add(stmtElement1);
		stmtElementList.add(stmtElement2);
		
		Statement stmt =new Statement();
		stmt.setStmtElementList(stmtElementList);
		statementList.add(stmt);
		
		Paragraph para = new Paragraph();
		para.setStatementList(statementList);
		
		assertNotNull(para.getStatementList());
		
	}

	

	@Test
	public void testGetCountOfSpacesAdded() {
		Paragraph para = new Paragraph();
		assertEquals(0,para.getCountOfSpacesAdded());
	}

	@Test
	public void testSetCountOfSpacesAdded() {
		Paragraph para = new Paragraph();
		int count=9;
		para.setCountOfSpacesAdded(count);
		assertEquals(count,para.getCountOfSpacesAdded());
	}

	@Test
	public void testGetCountOfCapitalConversion() {
		Paragraph para = new Paragraph();
		assertEquals(0,para.getCountOfCapitalConversion());
	}

	@Test
	public void testSetCountOfCapitalConversion() {
		Paragraph para = new Paragraph();
		int count=9;
		para.setCountOfCapitalConversion(count);
		assertEquals(count,para.getCountOfCapitalConversion());
	}

	@Test
	public void testGetCountOfConsonantAdjustedForA() {
		Paragraph para = new Paragraph();
		assertEquals(0,para.getCountOfConsonantAdjustedForA());
	}
	

	@Test
	public void testSetCountOfConsonantAdjustedForA() {
		Paragraph para = new Paragraph();
		int count=9;
		para.setCountOfConsonantAdjustedForA(count);
		assertEquals(count,para.getCountOfConsonantAdjustedForA());
	}	

	@Test
	public void testGetCountOfConsonantAdjustedForAn() {
		Paragraph para = new Paragraph();
		assertEquals(0,para.getCountOfConsonantAdjustedForAn());
	}

	@Test
	public void testSetCountOfConsonantAdjustedForAn() {
		Paragraph para = new Paragraph();
		int count=9;
		para.setCountOfConsonantAdjustedForAn(count);
		assertEquals(count,para.getCountOfConsonantAdjustedForAn());
	}	

}
