package com.grammer.test;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ ConsonantValidatorRectifierTest.class,
		ParagraphParserTest.class, ParagraphTest.class, PunctuationTest.class,
		SpacesAfterPunctuationValidatorRectifierTest.class,
		StartWithCapitalsValidatorRectifierTest.class,
		StatementElementParserTest.class, StatementParserTest.class,
		StatementTest.class, ValidatorsFactoryTest.class, WhitespaceTest.class,
		WordTest.class })

public class AllTests {

}
