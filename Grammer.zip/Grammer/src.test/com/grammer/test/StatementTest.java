package com.grammer.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Statement;
import com.grammer.Word;
import com.grammer.interfaces.StatementElement;

public class StatementTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetStmtElementList() {
		Statement stmt = new Statement();
		List<StatementElement> stmtElementList = new ArrayList<StatementElement>();
		StatementElement stmtElement = new Word("Hello");
		stmtElementList.add(stmtElement);
		stmt.setStmtElementList(stmtElementList);
		assertEquals(stmtElementList, stmt.getStmtElementList());
	}

	@Test
	public void testSetStmtElementList() {
		Statement stmt = new Statement();
		List<StatementElement> stmtElementList = new ArrayList<StatementElement>();
		StatementElement stmtElement = new Word("Hello");
		stmtElementList.add(stmtElement);
		stmt.setStmtElementList(stmtElementList);
		assertEquals(1, stmt.getStmtElementList().size());
	}

	@Test
	public void testSetStmtElementListForNull() {
		Statement stmt = new Statement();
		List<StatementElement> stmtElementList=null;
		stmt.setStmtElementList(stmtElementList);
		assertNull(stmt.getStmtElementList());
	}
}
