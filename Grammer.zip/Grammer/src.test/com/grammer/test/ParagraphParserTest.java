package com.grammer.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.grammer.parsers.ParagraphParser;

public class ParagraphParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParseForNotNull() {

		ParagraphParser parser = new ParagraphParser();
		String input = "Hi,this is not done. Try again.";
		assertNotNull(parser.parse(input));
	}

	
	@Test
	public void testParseForValidParse() {

		ParagraphParser parser = new ParagraphParser();
		String input = "Hi,this is not done.try again.";
		assertEquals("Hi,this is not done .try again .",parser.parse(input).toString());
	}

}
