package com.grammer.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Paragraph;
import com.grammer.Punctuation;
import com.grammer.Statement;
import com.grammer.Whitespace;
import com.grammer.Word;
import com.grammer.interfaces.StatementElement;
import com.grammer.parsers.ParagraphParser;

public class ParagraphParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParseForNotNull() {

		ParagraphParser parser = new ParagraphParser();
		String input = "Hi,this is not done. Try again.";
		assertNotNull(parser.parse(input));
	}

	
	@Test
	public void testParseForValidParse() {

		ParagraphParser parser = new ParagraphParser();
		String input = "Hi,this is not done.try again.";
		
		
		//assertEquals(createParagraph(input), parser.parse(input));
		
		assertEquals("Hi, this is not done. try again. ",parser.parse(input).toString());
	}

	/*
	private Paragraph createParagraph(String input){
		
		Paragraph para = new Paragraph();
		List<Statement> statementList = new ArrayList<Statement>();
		Statement stmt = new Statement();
		List<StatementElement> stmtElementList = new ArrayList<StatementElement>();
		
		StatementElement word1= new Word("Hi");
		StatementElement punct1 = new Punctuation(',');
		StatementElement word2= new Word("this");
		StatementElement space1= new Whitespace();
		StatementElement word3= new Word("is");
		StatementElement space2= new Whitespace();
		StatementElement word4= new Word("not");
		StatementElement space3= new Whitespace();
		StatementElement word5= new Word("done");
		StatementElement punct2 = new Punctuation('.');
		StatementElement space4 = new Whitespace();
		StatementElement word6= new Word("try");
		StatementElement space5= new Whitespace();
		StatementElement word7= new Word("again");
		StatementElement punct3 = new Punctuation('.');
		StatementElement space6= new Whitespace();
		
		
		stmtElementList.add(word1);
		stmtElementList.add(punct1); 
		stmtElementList.add(word2);
		stmtElementList.add(space1);
		stmtElementList.add(word3);
		stmtElementList.add(space2);
		stmtElementList.add(word4);
		stmtElementList.add(space3);
		stmtElementList.add(word5);
		stmtElementList.add(punct2);
		stmtElementList.add(space4);
		stmtElementList.add(word6);
		stmtElementList.add(space5);
		stmtElementList.add(word7);
		stmtElementList.add(punct3);
		stmtElementList.add(space6);
				
		stmt.setStmtElementList(stmtElementList);
		
		statementList.add(stmt);
		
		para.setStatementList(statementList);
		System.out.println(para.toString());
		return para;
	}
	*/
}
