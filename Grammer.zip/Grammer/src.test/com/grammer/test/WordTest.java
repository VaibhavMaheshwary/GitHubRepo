package com.grammer.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Word;

public class WordTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testWordConstructor() {
		Word word = new Word();
		assertNull(word.getActualWord());
	}

	@Test
	public void testGetActualWord() {
		Word word = new Word("Hello");
		assertEquals("Hello",word.getActualWord());
	}

	@Test
	public void testSetActualWord() {
		Word word = new Word();
		word.setActualWord("Hello");
		assertEquals("Hello",word.getActualWord());
	}

	@Test
	public void testToString() {
		Word word = new Word("Hello");
		assertEquals("Hello",word.toString());
	}

}
