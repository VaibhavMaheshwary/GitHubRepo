package com.grammer.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Paragraph;
import com.grammer.Validators.SpacesAfterPunctuationValidatorRectifier;
import com.grammer.parsers.ParagraphParser;

public class SpacesAfterPunctuationValidatorRectifierTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidateAndRectify() {
		String value = "Hi I am fine.but.how are you.";
		Paragraph input = new ParagraphParser().parse(value);
		SpacesAfterPunctuationValidatorRectifier validator = new SpacesAfterPunctuationValidatorRectifier();
		validator.validateAndRectify(input);
		Assert.assertEquals("Hi I am fine .but .how are you .",input.toString());
	}

}
