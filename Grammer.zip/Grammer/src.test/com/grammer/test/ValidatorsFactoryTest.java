package com.grammer.test;

import java.util.List;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.ValidatorsFactory;
import com.grammer.interfaces.Validator;

public class ValidatorsFactoryTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testGetAllValidators() {
		List<Validator> list = ValidatorsFactory.getAllValidators();
		Assert.assertNotNull(list);
	
	}

}
