package com.grammer.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Punctuation;
import com.grammer.Whitespace;

public class PunctuationTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testPunctuation() {
		Punctuation punc = new Punctuation('?');
		assertNotNull(punc);
	}

	@Test
	public void testGetCurrentChar() {
		Punctuation punc = new Punctuation('?');
		assertEquals('?', punc.getCurrentChar());

	}

	@Test
	public void testSetCurrentChar() {
		Punctuation punc = new Punctuation();
		punc.setCurrentChar('?');
		assertEquals('?',punc.getCurrentChar());
	}
	

	@Test
	public void testToString() {
		Punctuation punc = new Punctuation('?');
		assertEquals("?",punc.toString());
	
	}

}
