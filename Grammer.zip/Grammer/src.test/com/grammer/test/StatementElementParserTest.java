package com.grammer.test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.grammer.interfaces.StatementElement;
import com.grammer.parsers.StatementElementParser;

public class StatementElementParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParseLineToGetNumberOfTokens() {
		StatementElementParser parser = new StatementElementParser();
		String currentWord = "Hi how}are you";
		 List<StatementElement> stmtElementList = parser.parse(currentWord);
		 Assert.assertEquals(4,stmtElementList.size());
		
	}

}
