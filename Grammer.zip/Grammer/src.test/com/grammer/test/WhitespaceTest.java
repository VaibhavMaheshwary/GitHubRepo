package com.grammer.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Whitespace;
import com.grammer.Word;

public class WhitespaceTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testWhitespace() {
		Whitespace space = new Whitespace();
		assertNotNull(space.getSpace());
	
	}

	@Test
	public void testWhitespaceString() {
		Whitespace space = new Whitespace(" ");
		assertEquals(" ", space.getSpace());
	}

	@Test
	public void testGetSpace() {
		Whitespace space = new Whitespace(" ");
		assertEquals(" ", space.getSpace());
	}

	@Test
	public void testSetSpace() {
		Whitespace space = new Whitespace();
		space.setSpace(" ");
		assertEquals(" ",space.getSpace());
	}

	@Test
	public void testToString() {
		Whitespace space = new Whitespace(" ");
		assertEquals(" ",space.toString());
	
	}

}
