package com.grammer.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Paragraph;
import com.grammer.Validators.StartWithCapitalsValidatorRectifier;
import com.grammer.parsers.ParagraphParser;

public class StartWithCapitalsValidatorRectifierTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testValidateAndRectify() {
		String value = "This is.a planet.of a eagle.";
		Paragraph input = new ParagraphParser().parse(value);
		StartWithCapitalsValidatorRectifier validator = new StartWithCapitalsValidatorRectifier();
		validator.validateAndRectify(input);
		Assert.assertEquals("This is .A planet .Of a eagle .",input.toString());
	}

}
