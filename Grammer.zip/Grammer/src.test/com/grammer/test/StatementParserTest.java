package com.grammer.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.grammer.Statement;
import com.grammer.parsers.StatementParser;

public class StatementParserTest {

	@Before
	public void setUp() throws Exception {
	}

	@After
	public void tearDown() throws Exception {
	}

	@Test
	public void testParseForTokenCount() {
		StatementParser parser = new StatementParser();
		String currentStmt = "Hi,I am fine.";
		Statement stmt = parser.parse(currentStmt);
		assertEquals(12,stmt.getStmtElementList().size());
	}

}
