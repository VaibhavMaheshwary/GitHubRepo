package com.grammer.Validators;

import java.util.List;

import com.grammer.Paragraph;
import com.grammer.Punctuation;
import com.grammer.Statement;
import com.grammer.Whitespace;
import com.grammer.Word;
import com.grammer.interfaces.StatementElement;
import com.grammer.interfaces.Validator;

public class StartWithCapitalsValidatorRectifier implements Validator{

	@Override
	public void validateAndRectify(Paragraph input) {
		// TODO Auto-generated method stub
		
		List<Statement> statementList = input.getStatementList();
		
		for(Statement stmt : statementList){
			List<StatementElement> statementElementList = stmt.getStmtElementList();
			for(int stmtElementIndex=0;stmtElementIndex<statementElementList.size();stmtElementIndex++){
				StatementElement stmtElement =  statementElementList.get(stmtElementIndex);
				if (stmtElement instanceof Word){
					String word = ((Word)stmtElement).getActualWord();
					StringBuffer sb = new StringBuffer(word);
					sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
					((Word)stmtElement).setActualWord(sb.toString());
					input.setCountOfCapitalConversion(input.getCountOfCapitalConversion()+1);
					break;
					
				}
			}
		}
		
	}

	
}
