package com.grammer.Validators;

import java.util.List;

import com.grammer.Paragraph;
import com.grammer.Punctuation;
import com.grammer.Statement;
import com.grammer.Whitespace;
import com.grammer.interfaces.StatementElement;
import com.grammer.interfaces.Validator;

public class SpacesAfterPunctuationValidatorRectifier implements Validator {

	@Override
	public void validateAndRectify(Paragraph input) {
		// TODO Auto-generated method stub
		List<Statement> statementList = input.getStatementList();
		
		for(Statement stmt : statementList){
			List<StatementElement> statementElementList = stmt.getStmtElementList();
			for(int stmtElementIndex=0;stmtElementIndex<statementElementList.size();stmtElementIndex++){
				StatementElement stmtElement =  statementElementList.get(stmtElementIndex);
				if (stmtElement instanceof Punctuation){
					if(stmtElementIndex+1 < statementElementList.size()){
						StatementElement nextStmtElement =  statementElementList.get(stmtElementIndex+1);
						if(nextStmtElement instanceof Whitespace){
							//do nothing
						}else{
							statementElementList.add(stmtElementIndex+1, new Whitespace(" "));
							input.setCountOfSpacesAdded(input.getCountOfSpacesAdded()+1);
						}	
					}
					
				}
			}
		}
	}
}
