package com.grammer.Validators;

import java.util.List;

import com.grammer.Paragraph;
import com.grammer.Statement;
import com.grammer.Word;
import com.grammer.enums.VowelsEnum;
import com.grammer.interfaces.StatementElement;
import com.grammer.interfaces.Validator;

public class ConsonantValidatorRectifier implements Validator {

	@Override
	public void validateAndRectify(Paragraph input) {
		// TODO Auto-generated method stub
    List<Statement> statementList = input.getStatementList();
		
		for(Statement stmt : statementList){
			List<StatementElement> statementElementList = stmt.getStmtElementList();
			for(int stmtElementIndex=0;stmtElementIndex<statementElementList.size();stmtElementIndex++){
				StatementElement stmtElement =  statementElementList.get(stmtElementIndex);
				if (stmtElement instanceof Word){
						String word = ((Word) stmtElement).getActualWord();
						if("AN".equalsIgnoreCase(word)){
							int tempCounter=stmtElementIndex + 1;
							while(tempCounter < statementElementList.size()){
								StatementElement tempStmtElement =  statementElementList.get(tempCounter);
								if (tempStmtElement instanceof Word){
									String tempWord = ((Word) tempStmtElement).getActualWord();
									if(String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.A.toString()) ||
											String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.E.toString()) ||
													String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.I.toString()) ||
															String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.O.toString()) ||
																	String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.U.toString())){
									//do nothing
									}else{
										((Word) stmtElement).setActualWord("a");
										input.setCountOfConsonantAdjustedForAn(input.getCountOfConsonantAdjustedForAn() +1);
									}
									break;
									
								}
								tempCounter++;
							}
						}else if("A".equalsIgnoreCase(word)){
							int tempCounter=stmtElementIndex + 1;
							while(tempCounter < statementElementList.size()){
								StatementElement tempStmtElement =  statementElementList.get(tempCounter);
								if (tempStmtElement instanceof Word){
									String tempWord = ((Word) tempStmtElement).getActualWord();
									if(String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.A.toString()) ||
											String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.E.toString()) ||
													String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.I.toString()) ||
															String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.O.toString()) ||
																	String.valueOf(tempWord.charAt(0)).equalsIgnoreCase(VowelsEnum.U.toString())){
										((Word) stmtElement).setActualWord("an");
										input.setCountOfConsonantAdjustedForA(input.getCountOfConsonantAdjustedForA() +1);
										
									}else{
									 //do nothing
									}
									break;
									
								}
								tempCounter++;
							}
						}
					
				}
			}
		}

	}

}
