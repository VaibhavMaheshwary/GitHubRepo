package com.grammer;

import java.util.List;

import com.grammer.interfaces.StatementElement;

public class Paragraph {
	
	private List<Statement> statementList;
	
	private int countOfSpacesAdded;
	
	private int countOfCapitalConversion;
	
	private int countOfConsonantAdjustedForA;
	
	private int countOfConsonantAdjustedForAn;
	
	
	public List<Statement> getStatementList() {
		return statementList;
	}


	public void setStatementList(List<Statement> statementList) {
		this.statementList = statementList;
	}

	public String toString(){
		StringBuffer sb = new StringBuffer();
		
		List<Statement> statementList = this.getStatementList();
		if(statementList == null){
			sb.append("Paragraph is empty");
			return sb.toString();
		}
		
		for(Statement stmt : statementList){
			List<StatementElement> stmtElementList = stmt.getStmtElementList();
			for(StatementElement stmtElement : stmtElementList){
				sb.append(stmtElement.toString());
			}
			
		}
		
		return sb.toString();
	}

	

	public int getCountOfSpacesAdded() {
		return countOfSpacesAdded;
	}


	public void setCountOfSpacesAdded(int countOfSpacesAdded) {
		this.countOfSpacesAdded = countOfSpacesAdded;
	}


	public int getCountOfCapitalConversion() {
		return countOfCapitalConversion;
	}


	public void setCountOfCapitalConversion(int countOfCapitalConversion) {
		this.countOfCapitalConversion = countOfCapitalConversion;
	}


	public int getCountOfConsonantAdjustedForA() {
		return countOfConsonantAdjustedForA;
	}


	public void setCountOfConsonantAdjustedForA(int countOfConsonantAdjustedForA) {
		this.countOfConsonantAdjustedForA = countOfConsonantAdjustedForA;
	}


	public int getCountOfConsonantAdjustedForAn() {
		return countOfConsonantAdjustedForAn;
	}


	public void setCountOfConsonantAdjustedForAn(int countOfConsonantAdjustedForAn) {
		this.countOfConsonantAdjustedForAn = countOfConsonantAdjustedForAn;
	}
}
