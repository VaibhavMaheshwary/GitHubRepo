package com.grammer;

import com.grammer.interfaces.StatementElement;

public class Word implements StatementElement {

	private String actualWord;

	public Word() {
		 
	}
	
	
	public Word(String actualWord) {

		this.actualWord = actualWord; 
	}

	public String getActualWord() {
		return actualWord;
	}

	public void setActualWord(String actualWord) {
		this.actualWord = actualWord;
	}
	
	public String toString(){
		
		return String.valueOf(this.actualWord);
	}

}
