package com.grammer;

import java.util.Iterator;
import java.util.List;

import com.grammer.interfaces.Validator;
import com.grammer.parsers.ParagraphParser;

public class TestGrammer {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ParagraphParser parser = new ParagraphParser();

		String input = "Hello hi.how,are you an elephant a owl an planet.";
		Paragraph para = parser.parse(input);
		
		List<Validator> listOfValidators = ValidatorsFactory.getAllValidators();
		Iterator<Validator> iter = listOfValidators.iterator();
		
		while(iter.hasNext()){
			iter.next().validateAndRectify(para);
		}
		
		
		System.out.println(para.toString());

		
		int totalIssues= para.getCountOfCapitalConversion() + para.getCountOfConsonantAdjustedForA()+
				para.getCountOfConsonantAdjustedForAn()+
				para.getCountOfSpacesAdded();
		if(totalIssues == 0){
			System.out.println("Congrats No issues found");
		}else{
			System.out.println("Total Issues : " + totalIssues);
			System.out.println("Total Capital Conversions " + para.getCountOfCapitalConversion());
			System.out.println("Total ConsonantAdjustedForA " + para.getCountOfConsonantAdjustedForA());
			System.out.println("Total ConsonantAdjustedForAN " + para.getCountOfConsonantAdjustedForAn());
			System.out.println("Total Count of spaces added " + para.getCountOfSpacesAdded());
			
		}
				
	}

}
