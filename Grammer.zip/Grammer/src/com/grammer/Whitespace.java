package com.grammer;

import com.grammer.interfaces.StatementElement;

public class Whitespace implements StatementElement {

	private String space;
	
	public Whitespace(){
		space=" ";
	}
	
	public Whitespace(String space){
		
		this.space = space;
	}

	public String getSpace() {
		return space;
	}

	public void setSpace(String space) {
		this.space = space;
	}
	
	public String toString(){
		
		return String.valueOf(this.space);
	}
	
}
