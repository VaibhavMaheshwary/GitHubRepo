package com.grammer;

import com.grammer.interfaces.StatementElement;

public class Punctuation implements StatementElement {

	private char currentChar;

	public Punctuation() {

	
	}

	public Punctuation(char currentChar) {

		this.currentChar = currentChar;
	
	}

	public char getCurrentChar() {
		return currentChar;
	}

	public void setCurrentChar(char currentChar) {
		this.currentChar = currentChar;
	}
	
		
	public String toString(){
		
		return String.valueOf(this.currentChar);
	}

}
