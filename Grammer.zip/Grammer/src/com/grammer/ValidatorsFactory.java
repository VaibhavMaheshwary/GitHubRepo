package com.grammer;

import java.util.LinkedList;
import java.util.List;

import com.grammer.Validators.ConsonantValidatorRectifier;
import com.grammer.Validators.SpacesAfterPunctuationValidatorRectifier;
import com.grammer.Validators.StartWithCapitalsValidatorRectifier;
import com.grammer.interfaces.Validator;

public class ValidatorsFactory {
	
	public static List<Validator> getAllValidators(){
		 
		List<Validator> list = new LinkedList<Validator>();
		 list.add(new SpacesAfterPunctuationValidatorRectifier());
		 list.add(new StartWithCapitalsValidatorRectifier());
		 list.add(new ConsonantValidatorRectifier());
		
		 return list;
		
	}

}
