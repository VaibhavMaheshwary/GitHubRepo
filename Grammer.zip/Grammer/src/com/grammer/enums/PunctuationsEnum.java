package com.grammer.enums;

public enum PunctuationsEnum {

	COMMA(','), 
	SEMICOLON(';'), 
	FULLSTOP('.'),
	QUESTION_MARK('?'),
	EXCLAMATION_MARK('!'),
	COLON(':'),
	HYPHEN('-'),
	PARANTHESIS_OPEN('('),
	PARANTHESIS_CLOSE(')'),
	BRACES_OPEN('{'),
	BRACES_CLOSE('}'),
	BRACKETS_OPEN('['),
	BRACKETS_CLOSE(']'),
	QUOTES('\"');
		
	private char val;
	
	PunctuationsEnum(char value){
		this.val=value;
	}
	
	public char val() {
        return val;
    }
}
