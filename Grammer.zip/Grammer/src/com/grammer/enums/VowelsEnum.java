package com.grammer.enums;

public enum VowelsEnum {
	
	A('A'),
	E('E'),
	I('I'),
	O('O'),
	U('U');
	
	private char val;
	
	VowelsEnum(char value){
		this.val=value;
	}
	
	public char val() {
        return val;
    }


}
