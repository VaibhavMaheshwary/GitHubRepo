package com.grammer.enums;

public enum SpaceEnum {

	SPACE(" ");
	
	private String val;
	
	SpaceEnum(String value){
		this.val=value;
	}
	
	public String val() {
        return val;
    }

}
