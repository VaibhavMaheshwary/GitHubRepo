package com.grammer.parsers;

import java.util.ArrayList;
import java.util.List;

import com.grammer.Paragraph;
import com.grammer.Statement;

public class ParagraphParser {

	private Paragraph paragraph;
	
	public Paragraph parse(String input){
		
		String rawStatements[] = input.split("\\.");//String.valueOf(PunctuationsEnum.FULLSTOP.val()));
		
		if(rawStatements == null)
			return null;
		
		paragraph = new Paragraph();
		
		List<Statement> stmtList = new ArrayList<Statement>();
		StatementParser stmtParser =  new StatementParser();
		
		for(String currentLine : rawStatements){
			Statement currentStmt = stmtParser.parse(currentLine);	
			stmtList.add(currentStmt);
			
		}
		
		paragraph.setStatementList(stmtList);
		
		return paragraph;
	}
}
