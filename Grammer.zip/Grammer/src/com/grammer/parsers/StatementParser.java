package com.grammer.parsers;

import java.util.ArrayList;
import java.util.List;

import com.grammer.Punctuation;
import com.grammer.Statement;
import com.grammer.Whitespace;
import com.grammer.enums.PunctuationsEnum;
import com.grammer.enums.SpaceEnum;
import com.grammer.interfaces.StatementElement;

public class StatementParser {
	
	public Statement parse(String currentStmt){
		String rawWords[] = currentStmt.split(SpaceEnum.SPACE.val());
		List<StatementElement> stmtElementList=new ArrayList<StatementElement>();
		StatementElementParser stmtElementParser =  new StatementElementParser();
		 for(int currentWordIndex=0;currentWordIndex<rawWords.length;currentWordIndex++){
			String currentWord = rawWords[currentWordIndex];
			stmtElementList.addAll(stmtElementParser.parse(currentWord));
			if(currentWordIndex != rawWords.length-1){
				stmtElementList.add(new Whitespace());	
			}
			
		}
		
		stmtElementList.add(new Punctuation(PunctuationsEnum.FULLSTOP.val()));
		stmtElementList.add(new Whitespace());
		Statement stmt =  new Statement();
		stmt.setStmtElementList(stmtElementList);
		
		return stmt;
	}

}
