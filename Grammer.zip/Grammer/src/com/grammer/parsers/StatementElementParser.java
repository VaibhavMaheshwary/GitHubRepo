package com.grammer.parsers;

import java.util.ArrayList;
import java.util.List;

import com.grammer.Punctuation;
import com.grammer.Whitespace;
import com.grammer.Word;
import com.grammer.enums.PunctuationsEnum;
import com.grammer.interfaces.StatementElement;

public class StatementElementParser {

	public List<StatementElement> parse(String currentWord){
		
		int prevPosition = 0;
		List <StatementElement> stmtElementList = new ArrayList<StatementElement>();
			for(int currentPositionIndex=0;currentPositionIndex<currentWord.length();currentPositionIndex++){
				char currentChar = currentWord.charAt(currentPositionIndex);
				if(currentChar == PunctuationsEnum.BRACES_CLOSE.val() ||
					currentChar == PunctuationsEnum.BRACES_OPEN.val() ||
					currentChar == PunctuationsEnum.BRACKETS_CLOSE.val() ||
					currentChar == PunctuationsEnum.BRACKETS_OPEN.val() ||
					currentChar == PunctuationsEnum.COLON.val() ||
					currentChar == PunctuationsEnum.COMMA.val() ||
					currentChar == PunctuationsEnum.EXCLAMATION_MARK.val() ||
					currentChar == PunctuationsEnum.FULLSTOP.val() ||
					currentChar == PunctuationsEnum.PARANTHESIS_CLOSE.val() ||
					currentChar == PunctuationsEnum.PARANTHESIS_OPEN.val() ||
					currentChar == PunctuationsEnum.QUESTION_MARK.val() ||
					currentChar == PunctuationsEnum.QUOTES.val() ||
					currentChar == PunctuationsEnum.SEMICOLON.val()){
					
					int currentPunctuationPosition = currentPositionIndex;
					
					String actualWord = currentWord.substring(prevPosition, currentPunctuationPosition);
					
					stmtElementList.add(new Word(actualWord));
					stmtElementList.add(new Punctuation(currentChar));
					stmtElementList.add(new Whitespace());					
					prevPosition = currentPunctuationPosition + 1;
					
				}
			}
			
			if(prevPosition < currentWord.length()){
				String remainingWord = currentWord.substring(prevPosition, currentWord.length());
				stmtElementList.add(new Word(remainingWord));
			}
			
			
		
		return stmtElementList;
	}
}
