package com.grammer;

import java.util.List;

import com.grammer.interfaces.StatementElement;

public class Statement {

	private List<StatementElement> stmtElementList;

	public List<StatementElement> getStmtElementList() {
		return stmtElementList;
	}

	public void setStmtElementList(List<StatementElement> stmtElementList) {
		this.stmtElementList = stmtElementList;
	}
	
	
}
