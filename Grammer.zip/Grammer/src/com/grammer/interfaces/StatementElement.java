package com.grammer.interfaces;

public interface StatementElement {
	
	

}
