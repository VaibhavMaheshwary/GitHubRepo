package com.grammer.interfaces;

import com.grammer.Paragraph;

public interface Validator {
	
	void validateAndRectify(Paragraph input);

}
